package com.applandeo.materialcalendarview.listeners

import com.applandeo.materialcalendarview.CalendarDay

interface OnCalendarDayClickListener {
    fun onClick(calendarDay: CalendarDay)
}