package com.applandeo.materialcalendarview.listeners

import com.applandeo.materialcalendarview.CalendarDay

interface OnCalendarDayLongClickListener {
    fun onClick(calendarDay: CalendarDay)
}